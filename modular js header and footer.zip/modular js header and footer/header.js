class Header extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.innerHTML = `
    
	<p>glorified header </p>
	  
    `;
  }
}

customElements.define('header-component', Header);

