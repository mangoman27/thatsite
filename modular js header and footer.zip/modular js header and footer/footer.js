class Footer extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.innerHTML = `
	
     <p> glorified footer!</p>
	
    `;
  }
}

customElements.define('footer-component', Footer);